
# General settings
default['hubdrop']['paths']['home']  = '/var/hubdrop'
default['hubdrop']['paths']['app']  = '/var/hubdrop/app'
default['hubdrop']['paths']['repos']  = '/var/hubdrop/repos'
