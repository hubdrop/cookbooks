openssl Cookbook CHANGELOG
==========================
This file is used to list changes made in each version of the openssl cookbook.


v1.1.0
------
### Improvement
- **[COOK-3222](https://tickets.opscode.com/browse/COOK-3222)** - Allow setting length for `secure_password`

v1.0.2
------
- Add name attribute to metadata
